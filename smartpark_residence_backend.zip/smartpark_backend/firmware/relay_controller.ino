/*
 * SmartPark Residence — relay_controller.ino
 * ESP32 board driving a dry-contact relay wired to the barrier's manual
 * "open" button terminals. Subscribes to an MQTT topic and pulses the
 * relay for 1 second per OPEN command (mirrors a manual button press).
 *
 * Wiring:
 *   ESP32 GPIO 26  -> Relay module IN
 *   Relay COM/NO   -> Barrier controller's manual-open dry contact
 *
 * Broker topic layout (must match BarrierController.mqtt_topic in Django):
 *   smartpark/<complex_id>/gate/<gate_id>/barrier/cmd   payload: "OPEN"
 *   smartpark/<complex_id>/gate/<gate_id>/barrier/status payload: "online" (LWT)
 */

#include <WiFi.h>
#include <PubSubClient.h>

// ---- Configure per-device ----
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MQTT_HOST     = "192.168.1.10";   // mosquitto broker (or public IP behind nginx/mosquitto)
const int   MQTT_PORT     = 1883;
const char* MQTT_TOPIC_CMD    = "smartpark/1/gate/main/barrier/cmd";
const char* MQTT_TOPIC_STATUS = "smartpark/1/gate/main/barrier/status";
const char* DEVICE_ID = "barrier-main-01";

const int RELAY_PIN = 26;
const unsigned long PULSE_MS = 1000; // 1 second impulse, matches a manual button press

WiFiClient espClient;
PubSubClient mqtt(espClient);

void connectWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("WiFi ulanmoqda");
  while (WiFi.status() != WL_CONNECTED) {
    delay(400);
    Serial.print(".");
  }
  Serial.println(" ulandi: " + WiFi.localIP().toString());
}

void pulseBarrierOpen() {
  Serial.println("Shlagbaum: OCHISH impulsi yuborilmoqda");
  digitalWrite(RELAY_PIN, HIGH);
  delay(PULSE_MS);
  digitalWrite(RELAY_PIN, LOW);
}

void onMqttMessage(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
  msg.trim();

  if (String(topic) == MQTT_TOPIC_CMD && msg == "OPEN") {
    pulseBarrierOpen();
  }
}

void connectMqtt() {
  while (!mqtt.connected()) {
    Serial.print("MQTT brokerga ulanmoqda...");
    // Last-Will: if the device drops offline, the broker announces it —
    // Django's device-health poller can flag BarrierController.health = OFFLINE.
    if (mqtt.connect(DEVICE_ID, MQTT_TOPIC_STATUS, 0, true, "offline")) {
      Serial.println(" ulandi");
      mqtt.publish(MQTT_TOPIC_STATUS, "online", true);
      mqtt.subscribe(MQTT_TOPIC_CMD);
    } else {
      Serial.print("xato, rc=");
      Serial.print(mqtt.state());
      Serial.println(" 2 soniyadan keyin qayta urinish");
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);

  connectWiFi();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(onMqttMessage);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMqtt();
  mqtt.loop();
}
