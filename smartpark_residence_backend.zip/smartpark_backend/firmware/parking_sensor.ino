/*
 * SmartPark Residence — parking_sensor.ino
 * ESP32 + HC-SR04 ultrasonic sensor mounted above a parking slot.
 * Every 3 seconds, measures distance to detect a parked vehicle and
 * publishes FREE/OCCUPIED to MQTT — consumed by an iot_integration
 * webhook/subscriber that updates ParkingSlot.status in Django.
 *
 * Wiring:
 *   HC-SR04 TRIG -> ESP32 GPIO 5
 *   HC-SR04 ECHO -> ESP32 GPIO 18 (via voltage divider: sensor is 5V, ESP32 is 3.3V)
 *
 * Topic layout (must match OccupancySensor.device_uid mapping in Django):
 *   smartpark/1/slot/B1-102/occupancy   payload: "OCCUPIED" | "FREE"
 */

#include <WiFi.h>
#include <PubSubClient.h>

const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* MQTT_HOST     = "192.168.1.10";
const int   MQTT_PORT     = 1883;
const char* MQTT_TOPIC    = "smartpark/1/slot/B1-102/occupancy";
const char* DEVICE_ID     = "sensor-b1-102";

const int TRIG_PIN = 5;
const int ECHO_PIN = 18;
const float OCCUPIED_THRESHOLD_CM = 80.0; // distance below this = a car is present
const unsigned long READ_INTERVAL_MS = 3000;

WiFiClient espClient;
PubSubClient mqtt(espClient);

String lastPublishedState = "";
unsigned long lastReadAt = 0;

void connectWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) delay(400);
}

void connectMqtt() {
  while (!mqtt.connected()) {
    if (mqtt.connect(DEVICE_ID)) {
      // no-op: this device only publishes, it doesn't subscribe
    } else {
      delay(2000);
    }
  }
}

float readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long durationUs = pulseIn(ECHO_PIN, HIGH, 30000); // 30ms timeout ~= 5m max range
  if (durationUs == 0) return -1; // no echo received
  return durationUs * 0.0343 / 2.0; // speed of sound (cm/us) / round trip
}

void setup() {
  Serial.begin(115200);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  connectWiFi();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMqtt();
  mqtt.loop();

  if (millis() - lastReadAt >= READ_INTERVAL_MS) {
    lastReadAt = millis();
    float distance = readDistanceCm();
    if (distance < 0) return; // skip a failed reading rather than publish garbage

    String state = (distance <= OCCUPIED_THRESHOLD_CM) ? "OCCUPIED" : "FREE";
    if (state != lastPublishedState) {
      mqtt.publish(MQTT_TOPIC, state.c_str(), true);
      lastPublishedState = state;
      Serial.println("Joy holati: " + state + " (" + String(distance) + " sm)");
    }
  }
}
