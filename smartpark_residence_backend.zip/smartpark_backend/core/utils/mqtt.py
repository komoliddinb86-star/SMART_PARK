"""MQTT publishing helper for barrier controllers (single extension point)."""
import logging

logger = logging.getLogger("iot_integration.mqtt")


def publish_barrier_open(topic: str) -> None:
    """
    TODO(production): replace with a persistent paho-mqtt client connection
    (initialized once at worker/consumer startup) instead of a per-call connect.
    """
    logger.info("MQTT PUBLISH -> topic=%s payload=OPEN", topic)
