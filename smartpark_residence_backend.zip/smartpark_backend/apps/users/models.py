import uuid

from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Custom user supporting 4 actor roles across the ecosystem."""

    class Role(models.TextChoices):
        RESIDENT = "RESIDENT", "Rezident"
        GUARD = "GUARD", "Qorovul"
        TSJ_ADMIN = "TSJ_ADMIN", "TSJ Administratori"
        SUPERADMIN = "SUPERADMIN", "Super Administrator"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.RESIDENT)
    phone_number = models.CharField(max_length=20, unique=True)
    complex = models.ForeignKey(
        "complexes.ResidentialComplex",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="users",
        help_text="Multi-tenant chegarasi: foydalanuvchi biriktirilgan majmua.",
    )
    telegram_chat_id = models.CharField(max_length=64, blank=True, default="")
    fcm_token = models.CharField(max_length=255, blank=True, default="", help_text="Push xabarnoma uchun Firebase token")
    is_phone_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=["role", "complex"]),
            models.Index(fields=["phone_number"]),
        ]

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.role})"


class ResidentProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="resident_profile")
    apartment = models.ForeignKey(
        "complexes.Apartment", on_delete=models.SET_NULL, null=True, related_name="residents"
    )
    is_owner = models.BooleanField(default=True, help_text="Egasi (True) yoki ijarachi (False)")

    def __str__(self):
        return f"Resident: {self.user}"
