from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import ResidentProfile, User


@admin.register(User)
class SmartParkUserAdmin(UserAdmin):
    list_display = ("username", "get_full_name", "role", "complex", "phone_number", "is_phone_verified")
    list_filter = ("role", "complex", "is_phone_verified")
    fieldsets = UserAdmin.fieldsets + (
        ("SmartPark", {"fields": ("role", "complex", "phone_number", "telegram_chat_id", "fcm_token")}),
    )


admin.site.register(ResidentProfile)
