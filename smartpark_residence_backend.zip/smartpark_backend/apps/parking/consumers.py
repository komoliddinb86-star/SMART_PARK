from channels.generic.websocket import AsyncJsonWebsocketConsumer


class ParkingMapConsumer(AsyncJsonWebsocketConsumer):
    """ws/parking/<complex_id>/ — live FREE/OCCUPIED/RESERVED updates for the map UI."""

    async def connect(self):
        self.complex_id = self.scope["url_route"]["kwargs"]["complex_id"]
        self.group_name = f"parking_map_{self.complex_id}"
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def slot_update(self, event):
        await self.send_json(
            {"type": "slot_update", "slot_id": event["slot_id"], "code": event["code"], "status": event["status"]}
        )
