from rest_framework.routers import DefaultRouter

from .views import ParkingSlotViewSet, VehicleViewSet

router = DefaultRouter()
router.register("slots", ParkingSlotViewSet, basename="parking-slot")
router.register("vehicles", VehicleViewSet, basename="vehicle")

urlpatterns = router.urls
