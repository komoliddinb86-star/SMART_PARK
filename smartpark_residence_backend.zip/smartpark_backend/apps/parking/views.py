from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import ParkingSlot, Vehicle
from .serializers import ParkingSlotSerializer, VehicleSerializer
from .services import AllocationService, NoSlotAvailableError


class ParkingSlotViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = ParkingSlotSerializer

    def get_queryset(self):
        return ParkingSlot.objects.filter(zone__complex_id=self.request.user.complex_id).select_related("zone")

    @action(detail=False, methods=["post"], url_path="allocate")
    def allocate(self, request):
        apartment = request.user.resident_profile.apartment
        service = AllocationService(request.user.complex)
        try:
            result = service.allocate_for(apartment)
        except NoSlotAvailableError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_409_CONFLICT)
        return Response(ParkingSlotSerializer(result.slot).data, status=status.HTTP_201_CREATED)


class VehicleViewSet(viewsets.ModelViewSet):
    serializer_class = VehicleSerializer

    def get_queryset(self):
        return Vehicle.objects.filter(owner=self.request.user)
