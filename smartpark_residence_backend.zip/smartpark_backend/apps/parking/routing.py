from django.urls import re_path

from .consumers import ParkingMapConsumer

websocket_urlpatterns = [
    re_path(r"ws/parking/(?P<complex_id>\d+)/$", ParkingMapConsumer.as_asgi()),
]
