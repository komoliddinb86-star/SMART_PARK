from rest_framework import serializers

from .models import ParkingSlot, SlotReservation, SlotSwapRequest, Vehicle


class ParkingSlotSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParkingSlot
        fields = ["id", "zone", "code", "slot_type", "status", "position_x", "position_y", "assigned_apartment"]
        read_only_fields = ["status"]


class VehicleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vehicle
        fields = ["id", "license_plate", "make_model", "color", "is_active"]
        read_only_fields = ["owner"]

    def create(self, validated_data):
        validated_data["owner"] = self.context["request"].user
        return super().create(validated_data)


class SlotReservationSerializer(serializers.ModelSerializer):
    class Meta:
        model = SlotReservation
        fields = ["id", "slot", "apartment", "starts_at", "ends_at"]
        read_only_fields = fields


class SlotSwapRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = SlotSwapRequest
        fields = ["id", "requester_slot", "target_slot", "status", "created_at"]
        read_only_fields = ["status", "created_at"]
