"""Service Layer — Fair Parking Slot Allocation Engine (Strategy pattern)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

from django.db import transaction
from django.utils import timezone

from apps.complexes.models import Apartment, ResidentialComplex

from .models import AllocationPolicy, ParkingSlot, SlotReservation


class NoSlotAvailableError(Exception):
    pass


@dataclass
class AllocationResult:
    slot: ParkingSlot
    reservation: SlotReservation


class AllocationService:
    def __init__(self, complex_obj: ResidentialComplex):
        self.complex = complex_obj
        self.policy, _ = AllocationPolicy.objects.get_or_create(complex=complex_obj)

    @transaction.atomic
    def allocate_for(self, apartment: Apartment) -> AllocationResult:
        strategy_map = {
            AllocationPolicy.Strategy.QUEUE: self._allocate_queue,
            AllocationPolicy.Strategy.MONTHLY_ROTATION: self._allocate_monthly_rotation,
            AllocationPolicy.Strategy.BIDDING: self._allocate_bidding,
        }
        return strategy_map[self.policy.strategy](apartment)

    def _free_common_slots_qs(self):
        return (
            ParkingSlot.objects.select_for_update(skip_locked=True)
            .filter(zone__complex=self.complex, slot_type=ParkingSlot.SlotType.COMMON, status=ParkingSlot.Status.FREE)
            .order_by("id")
        )

    def _allocate_queue(self, apartment: Apartment) -> AllocationResult:
        slot = self._free_common_slots_qs().first()
        if slot is None:
            raise NoSlotAvailableError(f"{self.complex} da bo'sh umumiy joy yo'q")
        return self._commit_reservation(slot, apartment, ends_at=None)

    def _allocate_monthly_rotation(self, apartment: Apartment) -> AllocationResult:
        slot = self._free_common_slots_qs().first()
        if slot is None:
            raise NoSlotAvailableError(f"{self.complex} da bo'sh umumiy joy yo'q")
        month_end = (timezone.now().replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(seconds=1)
        return self._commit_reservation(slot, apartment, ends_at=month_end)

    def _allocate_bidding(self, apartment: Apartment) -> AllocationResult:
        raise NotImplementedError("Bidding strategy requires apps.billing integration")

    def _commit_reservation(self, slot: ParkingSlot, apartment: Apartment, ends_at) -> AllocationResult:
        slot.status = ParkingSlot.Status.RESERVED
        slot.save(update_fields=["status"])
        reservation = SlotReservation.objects.create(
            slot=slot, apartment=apartment, starts_at=timezone.now(), ends_at=ends_at
        )
        self._broadcast_slot_update(slot)
        return AllocationResult(slot=slot, reservation=reservation)

    def release(self, slot: ParkingSlot):
        slot.status = ParkingSlot.Status.FREE
        slot.save(update_fields=["status"])
        self._broadcast_slot_update(slot)

    def _broadcast_slot_update(self, slot: ParkingSlot):
        from asgiref.sync import async_to_sync
        from channels.layers import get_channel_layer

        channel_layer = get_channel_layer()
        if channel_layer is None:
            return
        async_to_sync(channel_layer.group_send)(
            f"parking_map_{self.complex.id}",
            {"type": "slot.update", "slot_id": slot.id, "code": slot.code, "status": slot.status},
        )
