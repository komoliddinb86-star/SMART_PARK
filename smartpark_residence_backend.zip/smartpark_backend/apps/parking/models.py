from django.conf import settings
from django.db import models


class ParkingSlot(models.Model):
    class SlotType(models.TextChoices):
        ASSIGNED = "ASSIGNED", "Biriktirilgan (shaxsiy)"
        COMMON = "COMMON", "Umumiy (navbat asosida)"
        GUEST = "GUEST", "Mehmon uchun"
        DISABLED = "DISABLED", "Nogironlar uchun"
        EMERGENCY = "EMERGENCY", "Favqulodda holat yo'lagi"

    class Status(models.TextChoices):
        FREE = "FREE", "Bo'sh"
        OCCUPIED = "OCCUPIED", "Band"
        RESERVED = "RESERVED", "Rezervlangan"
        RELEASED_BY_OWNER = "RELEASED_BY_OWNER", "Egasi vaqtincha bo'shatgan"
        OUT_OF_SERVICE = "OUT_OF_SERVICE", "Ishlamayapti"

    zone = models.ForeignKey("complexes.ParkingZone", on_delete=models.CASCADE, related_name="slots")
    code = models.CharField(max_length=20, help_text="Masalan: 'B1-102'")
    slot_type = models.CharField(max_length=20, choices=SlotType.choices, default=SlotType.COMMON)
    status = models.CharField(max_length=25, choices=Status.choices, default=Status.FREE)
    assigned_apartment = models.ForeignKey(
        "complexes.Apartment", null=True, blank=True, on_delete=models.SET_NULL, related_name="assigned_slots"
    )
    position_x = models.FloatField(default=0)
    position_y = models.FloatField(default=0)

    class Meta:
        unique_together = ("zone", "code")
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["zone", "status"]),
        ]

    def __str__(self):
        return f"{self.code} [{self.status}]"


class Vehicle(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="vehicles")
    license_plate = models.CharField(max_length=20, unique=True, db_index=True)
    make_model = models.CharField(max_length=100, blank=True)
    color = models.CharField(max_length=50, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.license_plate


class AllocationPolicy(models.Model):
    class Strategy(models.TextChoices):
        QUEUE = "QUEUE", "Navbat tizimi"
        MONTHLY_ROTATION = "MONTHLY_ROTATION", "Oylik rotatsiya"
        BIDDING = "BIDDING", "Auksion (bidding)"

    complex = models.OneToOneField(
        "complexes.ResidentialComplex", on_delete=models.CASCADE, related_name="allocation_policy"
    )
    strategy = models.CharField(max_length=20, choices=Strategy.choices, default=Strategy.QUEUE)

    def __str__(self):
        return f"{self.complex} — {self.strategy}"


class SlotReservation(models.Model):
    slot = models.ForeignKey(ParkingSlot, on_delete=models.CASCADE, related_name="reservations")
    apartment = models.ForeignKey("complexes.Apartment", on_delete=models.CASCADE, related_name="reservations")
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField(null=True, blank=True, help_text="Bo'sh = doimiy oylik rotatsiya davri")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["slot", "ends_at"])]


class SlotSwapRequest(models.Model):
    class Status(models.TextChoices):
        PENDING = "PENDING", "Kutilmoqda"
        ACCEPTED = "ACCEPTED", "Qabul qilindi"
        REJECTED = "REJECTED", "Rad etildi"

    requester_slot = models.ForeignKey(ParkingSlot, on_delete=models.CASCADE, related_name="swap_requests_out")
    target_slot = models.ForeignKey(ParkingSlot, on_delete=models.CASCADE, related_name="swap_requests_in")
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
