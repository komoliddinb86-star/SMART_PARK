from django.contrib import admin

from .models import AllocationPolicy, ParkingSlot, SlotReservation, SlotSwapRequest, Vehicle


@admin.register(ParkingSlot)
class ParkingSlotAdmin(admin.ModelAdmin):
    list_display = ("code", "zone", "slot_type", "status", "assigned_apartment")
    list_filter = ("slot_type", "status")
    search_fields = ("code",)


admin.site.register(Vehicle)
admin.site.register(AllocationPolicy)
admin.site.register(SlotReservation)
admin.site.register(SlotSwapRequest)
