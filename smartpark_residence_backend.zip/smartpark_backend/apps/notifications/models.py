from django.conf import settings
from django.db import models


class Notification(models.Model):
    class Channel(models.TextChoices):
        PUSH = "PUSH", "Push (Firebase)"
        SMS = "SMS", "SMS (Eskiz)"
        TELEGRAM = "TELEGRAM", "Telegram Bot"

    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    channel = models.CharField(max_length=10, choices=Channel.choices)
    title = models.CharField(max_length=200)
    body = models.TextField()
    sent_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
