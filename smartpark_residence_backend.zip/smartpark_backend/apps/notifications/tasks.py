import logging

from celery import shared_task
from django.utils import timezone

from .models import Notification

logger = logging.getLogger("notifications")


@shared_task
def send_notification(notification_id: int):
    notif = Notification.objects.select_related("recipient").get(id=notification_id)
    if notif.channel == Notification.Channel.PUSH:
        _send_push(notif)
    elif notif.channel == Notification.Channel.SMS:
        _send_sms(notif)
    elif notif.channel == Notification.Channel.TELEGRAM:
        _send_telegram(notif)
    notif.sent_at = timezone.now()
    notif.save(update_fields=["sent_at"])


def _send_push(notif: Notification):
    logger.info("PUSH -> %s: %s", notif.recipient, notif.title)  # TODO: firebase-admin messaging.send()


def _send_sms(notif: Notification):
    logger.info("SMS -> %s: %s", notif.recipient.phone_number, notif.body)  # TODO: Eskiz.uz API call


def _send_telegram(notif: Notification):
    if not notif.recipient.telegram_chat_id:
        return
    logger.info("TELEGRAM -> chat_id=%s: %s", notif.recipient.telegram_chat_id, notif.body)  # TODO: Bot API call
