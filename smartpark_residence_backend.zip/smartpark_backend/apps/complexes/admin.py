from django.contrib import admin

from .models import Apartment, Building, ParkingZone, ResidentialComplex

admin.site.register(ResidentialComplex)
admin.site.register(Building)
admin.site.register(Apartment)
admin.site.register(ParkingZone)
