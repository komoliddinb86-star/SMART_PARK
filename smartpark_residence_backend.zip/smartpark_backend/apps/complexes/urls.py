from rest_framework.routers import DefaultRouter

from .views import ResidentialComplexViewSet

router = DefaultRouter()
router.register("", ResidentialComplexViewSet, basename="complex")

urlpatterns = router.urls
