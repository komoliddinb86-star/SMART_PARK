from rest_framework import viewsets

from .models import ResidentialComplex
from .serializers import ResidentialComplexSerializer


class ResidentialComplexViewSet(viewsets.ReadOnlyModelViewSet):
    """Multi-tenant rule: a user only ever sees the complex they belong to."""

    serializer_class = ResidentialComplexSerializer

    def get_queryset(self):
        user = self.request.user
        qs = ResidentialComplex.objects.all().prefetch_related("buildings", "parking_zones")
        if user.role == user.Role.SUPERADMIN:
            return qs
        return qs.filter(id=user.complex_id)
