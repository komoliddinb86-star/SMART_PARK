from rest_framework import serializers

from .models import Apartment, Building, ParkingZone, ResidentialComplex


class ParkingZoneSerializer(serializers.ModelSerializer):
    class Meta:
        model = ParkingZone
        fields = ["id", "name", "layout_geojson", "is_underground"]


class BuildingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Building
        fields = ["id", "name"]


class ApartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Apartment
        fields = ["id", "number", "building"]


class ResidentialComplexSerializer(serializers.ModelSerializer):
    parking_zones = ParkingZoneSerializer(many=True, read_only=True)
    buildings = BuildingSerializer(many=True, read_only=True)

    class Meta:
        model = ResidentialComplex
        fields = ["id", "name", "address", "buildings", "parking_zones", "created_at"]
