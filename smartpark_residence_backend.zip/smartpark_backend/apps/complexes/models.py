from django.db import models


class ResidentialComplex(models.Model):
    """Top-level multi-tenant boundary — data never crosses complexes."""

    name = models.CharField(max_length=255)
    address = models.CharField(max_length=500)
    # Plain lat/lng instead of a PostGIS PointField: no location field in this
    # project actually needs spatial queries (distance, containment, etc.),
    # so this avoids requiring GDAL/GEOS/PostGIS just to store a coordinate —
    # a meaningful simplification for local (non-Docker) setup on Windows.
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    tsj_admin_org_name = models.CharField(max_length=255, blank=True)
    timezone = models.CharField(max_length=64, default="Asia/Tashkent")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class Building(models.Model):
    complex = models.ForeignKey(ResidentialComplex, on_delete=models.CASCADE, related_name="buildings")
    name = models.CharField(max_length=100, help_text="Masalan: 'A' blok")

    class Meta:
        unique_together = ("complex", "name")

    def __str__(self):
        return f"{self.complex.name} — {self.name}"


class Apartment(models.Model):
    building = models.ForeignKey(Building, on_delete=models.CASCADE, related_name="apartments")
    number = models.CharField(max_length=20)

    class Meta:
        unique_together = ("building", "number")

    def __str__(self):
        return f"{self.building} / {self.number}"


class ParkingZone(models.Model):
    """A floor or outdoor lot within a complex."""

    complex = models.ForeignKey(ResidentialComplex, on_delete=models.CASCADE, related_name="parking_zones")
    name = models.CharField(max_length=100, help_text="Masalan: 'B-1 qavat' yoki 'Tashqi hovli'")
    layout_geojson = models.JSONField(null=True, blank=True, help_text="Frontend 2D xarita uchun zona konturi")
    is_underground = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.complex.name} — {self.name}"
