"""
python manage.py seed_demo_data

Populates a fresh database with one working complex so you can demo the
system (and defend it) without manually clicking through the admin panel.
Safe to re-run: uses get_or_create everywhere.

Creates:
  - 1 ResidentialComplex ("Bog'bon Residence") with a real Tashkent point
  - 1 Building ("A"), 6 Apartments
  - 1 ParkingZone ("B-1 qavat") with 12 ParkingSlots (mixed types/statuses)
  - Users: superadmin/admin123, tsj_admin/admin123, resident/resident123
  - 1 Vehicle for the resident, 1 sample GuestPass
"""
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone


class Command(BaseCommand):
    help = "Seed the database with one working demo complex (for local testing / diploma defense)."

    def handle(self, *args, **options):
        from apps.complexes.models import Apartment, Building, ParkingZone, ResidentialComplex
        from apps.guest_access.services import GuestPassService
        from apps.parking.models import AllocationPolicy, ParkingSlot, Vehicle
        from apps.users.models import ResidentProfile, User

        complex_obj, _ = ResidentialComplex.objects.get_or_create(
            name="Bog'bon Residence",
            defaults={
                "address": "Toshkent sh., Yunusobod tumani, Bog'bon ko'chasi 12",
                "latitude": 41.3111,
                "longitude": 69.2401,
                "tsj_admin_org_name": "Bog'bon TSJ MChJ",
            },
        )
        AllocationPolicy.objects.get_or_create(
            complex=complex_obj, defaults={"strategy": AllocationPolicy.Strategy.QUEUE}
        )

        building, _ = Building.objects.get_or_create(complex=complex_obj, name="A")
        apartments = []
        for num in range(1, 7):
            apt, _ = Apartment.objects.get_or_create(building=building, number=str(num))
            apartments.append(apt)

        zone, _ = ParkingZone.objects.get_or_create(
            complex=complex_obj, name="B-1 qavat", defaults={"is_underground": True}
        )

        slot_plan = [
            ("B1-101", ParkingSlot.SlotType.ASSIGNED, ParkingSlot.Status.OCCUPIED, apartments[0]),
            ("B1-102", ParkingSlot.SlotType.ASSIGNED, ParkingSlot.Status.OCCUPIED, apartments[1]),
            ("B1-103", ParkingSlot.SlotType.COMMON, ParkingSlot.Status.FREE, None),
            ("B1-104", ParkingSlot.SlotType.COMMON, ParkingSlot.Status.FREE, None),
            ("B1-105", ParkingSlot.SlotType.COMMON, ParkingSlot.Status.OCCUPIED, None),
            ("B1-106", ParkingSlot.SlotType.GUEST, ParkingSlot.Status.FREE, None),
            ("B1-107", ParkingSlot.SlotType.GUEST, ParkingSlot.Status.FREE, None),
            ("B1-108", ParkingSlot.SlotType.DISABLED, ParkingSlot.Status.FREE, None),
            ("B1-109", ParkingSlot.SlotType.EMERGENCY, ParkingSlot.Status.FREE, None),
            ("B1-110", ParkingSlot.SlotType.COMMON, ParkingSlot.Status.OUT_OF_SERVICE, None),
            ("B1-111", ParkingSlot.SlotType.COMMON, ParkingSlot.Status.FREE, None),
            ("B1-112", ParkingSlot.SlotType.COMMON, ParkingSlot.Status.FREE, None),
        ]
        for i, (code, slot_type, status, apt) in enumerate(slot_plan):
            ParkingSlot.objects.get_or_create(
                zone=zone, code=code,
                defaults={
                    "slot_type": slot_type, "status": status, "assigned_apartment": apt,
                    "position_x": i % 4, "position_y": i // 4,
                },
            )

        superadmin, created = User.objects.get_or_create(
            username="superadmin",
            defaults={"role": User.Role.SUPERADMIN, "phone_number": "+998900000001", "is_staff": True, "is_superuser": True},
        )
        if created:
            superadmin.set_password("admin123")
            superadmin.save()

        tsj_admin, created = User.objects.get_or_create(
            username="tsj_admin",
            defaults={"role": User.Role.TSJ_ADMIN, "phone_number": "+998900000002", "complex": complex_obj, "is_staff": True},
        )
        if created:
            tsj_admin.set_password("admin123")
            tsj_admin.save()

        resident, created = User.objects.get_or_create(
            username="resident",
            defaults={
                "role": User.Role.RESIDENT, "phone_number": "+998900000003",
                "complex": complex_obj, "first_name": "Aziz", "last_name": "Karimov",
            },
        )
        if created:
            resident.set_password("resident123")
            resident.save()
        ResidentProfile.objects.get_or_create(user=resident, defaults={"apartment": apartments[2], "is_owner": True})

        Vehicle.objects.get_or_create(owner=resident, license_plate="01A777BB", defaults={"make_model": "Chevrolet Cobalt", "color": "Oq"})

        GuestPassService.issue(
            issued_by=resident, vehicle_plate="01M214KX", guest_name="Diloram (mehmon)",
            expires_at=timezone.now() + timedelta(hours=4), assigned_slot=None,
        )

        self.stdout.write(self.style.SUCCESS(
            "Demo ma'lumotlar tayyor:\n"
            "  superadmin / admin123   (Django admin: /admin/)\n"
            "  tsj_admin  / admin123   (role=TSJ_ADMIN)\n"
            "  resident   / resident123 (role=RESIDENT, 3-xonadon, avtomobil 01A777BB)\n"
            f"  Complex: {complex_obj.name} (id={complex_obj.id}) — 12 ta joy, B-1 qavat"
        ))
