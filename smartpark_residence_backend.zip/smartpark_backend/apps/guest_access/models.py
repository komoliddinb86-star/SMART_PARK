import uuid

from django.conf import settings
from django.db import models


class GuestPass(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    issued_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="guest_passes")
    vehicle_plate = models.CharField(max_length=20, db_index=True)
    guest_name = models.CharField(max_length=150, blank=True)
    assigned_slot = models.ForeignKey(
        "parking.ParkingSlot", null=True, blank=True, on_delete=models.SET_NULL, related_name="guest_passes"
    )
    signed_token = models.TextField(help_text="Signed JWT encoded into the QR code")
    expires_at = models.DateTimeField(db_index=True)
    revoked = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [models.Index(fields=["vehicle_plate", "expires_at", "revoked"])]

    def __str__(self):
        return f"GuestPass({self.vehicle_plate})"
