import jwt
from django.conf import settings
from django.utils import timezone

from .models import GuestPass


class GuestPassService:
    @staticmethod
    def issue(*, issued_by, vehicle_plate: str, guest_name: str, expires_at, assigned_slot=None) -> GuestPass:
        payload = {"plate": vehicle_plate, "exp": int(expires_at.timestamp()), "iss": str(issued_by.id)}
        token = jwt.encode(payload, settings.SECRET_KEY, algorithm="HS256")
        return GuestPass.objects.create(
            issued_by=issued_by, vehicle_plate=vehicle_plate, guest_name=guest_name,
            assigned_slot=assigned_slot, signed_token=token, expires_at=expires_at,
        )

    @staticmethod
    def revoke_expired() -> int:
        expired = GuestPass.objects.filter(expires_at__lt=timezone.now(), revoked=False)
        return expired.update(revoked=True)
