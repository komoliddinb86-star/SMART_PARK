from rest_framework import viewsets

from .models import GuestPass
from .serializers import GuestPassSerializer
from .services import GuestPassService


class GuestPassViewSet(viewsets.ModelViewSet):
    serializer_class = GuestPassSerializer
    http_method_names = ["get", "post", "delete"]

    def get_queryset(self):
        return GuestPass.objects.filter(issued_by=self.request.user)

    def perform_create(self, serializer):
        GuestPassService.issue(issued_by=self.request.user, **serializer.validated_data)
