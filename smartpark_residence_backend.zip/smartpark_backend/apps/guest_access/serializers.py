from rest_framework import serializers

from .models import GuestPass


class GuestPassSerializer(serializers.ModelSerializer):
    class Meta:
        model = GuestPass
        fields = ["id", "vehicle_plate", "guest_name", "assigned_slot", "expires_at", "revoked", "signed_token"]
        read_only_fields = ["id", "revoked", "signed_token"]
