from django.contrib import admin

from .models import GuestPass


@admin.register(GuestPass)
class GuestPassAdmin(admin.ModelAdmin):
    list_display = ("vehicle_plate", "guest_name", "issued_by", "expires_at", "revoked")
    list_filter = ("revoked",)
