from celery import shared_task

from .services import GuestPassService


@shared_task
def revoke_expired_guest_passes():
    """Scheduled via Celery Beat every 5 minutes (see settings.CELERY_BEAT_SCHEDULE)."""
    return GuestPassService.revoke_expired()
