from rest_framework.routers import DefaultRouter

from .views import GuestPassViewSet

router = DefaultRouter()
router.register("", GuestPassViewSet, basename="guest-pass")

urlpatterns = router.urls
