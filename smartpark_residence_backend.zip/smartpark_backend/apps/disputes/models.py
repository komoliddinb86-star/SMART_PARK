from django.conf import settings
from django.db import models


class Ticket(models.Model):
    class Status(models.TextChoices):
        RECEIVED = "RECEIVED", "Qabul qilindi"
        UNDER_REVIEW = "UNDER_REVIEW", "Ko'rib chiqilmoqda"
        RESOLVED = "RESOLVED", "Hal qilindi"
        CLOSED = "CLOSED", "Yopildi"

    reported_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="tickets")
    related_slot = models.ForeignKey(
        "parking.ParkingSlot", null=True, blank=True, on_delete=models.SET_NULL, related_name="tickets"
    )
    description = models.TextField()
    photo = models.ImageField(upload_to="tickets/%Y/%m/", blank=True, null=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.RECEIVED)
    created_at = models.DateTimeField(auto_now_add=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=["status", "-created_at"])]
