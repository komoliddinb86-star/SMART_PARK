from rest_framework import serializers, viewsets
from rest_framework.routers import DefaultRouter

from .models import Ticket


class TicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ticket
        fields = ["id", "related_slot", "description", "photo", "status", "created_at", "resolved_at"]
        read_only_fields = ["status", "created_at", "resolved_at"]


class TicketViewSet(viewsets.ModelViewSet):
    serializer_class = TicketSerializer
    http_method_names = ["get", "post"]

    def get_queryset(self):
        user = self.request.user
        if user.role in (user.Role.TSJ_ADMIN, user.Role.SUPERADMIN):
            return Ticket.objects.filter(reported_by__complex_id=user.complex_id)
        return Ticket.objects.filter(reported_by=user)

    def perform_create(self, serializer):
        serializer.save(reported_by=self.request.user)


router = DefaultRouter()
router.register("", TicketViewSet, basename="ticket")

urlpatterns = router.urls
