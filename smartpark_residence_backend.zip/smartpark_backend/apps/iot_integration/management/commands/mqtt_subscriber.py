"""
python manage.py mqtt_subscriber

Long-running bridge between the MQTT broker (Mosquitto) and Django state.
Run this as its own process/container (see docker-compose.yml) — it is NOT
a Celery task, since it needs a persistent blocking connection.

Topics consumed:
  smartpark/<complex_id>/slot/<slot_code>/occupancy   payload: "FREE" | "OCCUPIED"
  smartpark/<complex_id>/gate/<gate_id>/barrier/status payload: "online" | "offline" (LWT)

On each occupancy message:
  1. Updates ParkingSlot.status (unless the slot is RESERVED/OUT_OF_SERVICE —
     a physical presence reading should not silently clear a TSJ-admin hold).
  2. Broadcasts the change to ws/parking/<complex_id>/ so the live map and
     resident app update without polling.
"""
import logging

import django
from django.core.management.base import BaseCommand

logger = logging.getLogger("iot_integration.mqtt_subscriber")


class Command(BaseCommand):
    help = "Subscribe to Mosquitto topics and sync IoT sensor/controller state into Django."

    def handle(self, *args, **options):
        try:
            import paho.mqtt.client as mqtt
        except ImportError:
            self.stderr.write(self.style.ERROR(
                "paho-mqtt o'rnatilmagan. `pip install paho-mqtt` ishga tushiring."
            ))
            return

        from django.conf import settings

        client = mqtt.Client(client_id="django-smartpark-subscriber")
        client.on_connect = self._make_on_connect()
        client.on_message = self._on_message

        self.stdout.write(self.style.SUCCESS(
            f"MQTT brokerga ulanmoqda: {settings.MQTT_BROKER_HOST}:{settings.MQTT_BROKER_PORT}"
        ))
        client.connect(settings.MQTT_BROKER_HOST, settings.MQTT_BROKER_PORT, keepalive=60)
        client.loop_forever()  # blocking — this command is meant to run as its own process

    def _make_on_connect(self):
        def on_connect(client, userdata, flags, rc):
            if rc == 0:
                client.subscribe("smartpark/+/slot/+/occupancy")
                client.subscribe("smartpark/+/gate/+/barrier/status")
                logger.info("MQTT ulandi, topic'larga obuna bo'lindi")
            else:
                logger.error("MQTT ulanish xatosi, rc=%s", rc)
        return on_connect

    def _on_message(self, client, userdata, msg):
        try:
            parts = msg.topic.split("/")
            payload = msg.payload.decode().strip()

            if len(parts) == 5 and parts[2] == "slot" and parts[4] == "occupancy":
                self._handle_occupancy(complex_id=parts[1], slot_code=parts[3], payload=payload)
            elif len(parts) == 5 and parts[2] == "gate" and parts[4] == "status":
                self._handle_barrier_status(complex_id=parts[1], gate_id=parts[3], payload=payload)
        except Exception:
            logger.exception("MQTT xabarini qayta ishlashda xato: topic=%s", msg.topic)

    def _handle_occupancy(self, complex_id: str, slot_code: str, payload: str):
        from apps.parking.models import ParkingSlot

        new_status = ParkingSlot.Status.OCCUPIED if payload == "OCCUPIED" else ParkingSlot.Status.FREE

        slot = (
            ParkingSlot.objects.filter(zone__complex_id=complex_id, code=slot_code)
            .exclude(status__in=[ParkingSlot.Status.RESERVED, ParkingSlot.Status.OUT_OF_SERVICE])
            .first()
        )
        if slot is None:
            return  # unknown slot, or a hold that a sensor reading must not override

        if slot.status != new_status:
            slot.status = new_status
            slot.save(update_fields=["status"])
            self._broadcast_slot_update(complex_id, slot)

    def _handle_barrier_status(self, complex_id: str, gate_id: str, payload: str):
        from apps.iot_integration.models import ANPRCamera, DeviceHealth

        health = DeviceHealth.ONLINE if payload == "online" else DeviceHealth.OFFLINE
        camera = ANPRCamera.objects.filter(complex_id=complex_id, gate_name__iexact=gate_id).first()
        if camera is None or not hasattr(camera, "barrier"):
            return
        camera.barrier.health = health
        camera.barrier.save(update_fields=["health"])

    def _broadcast_slot_update(self, complex_id: str, slot):
        from asgiref.sync import async_to_sync
        from channels.layers import get_channel_layer

        channel_layer = get_channel_layer()
        if channel_layer is None:
            return
        async_to_sync(channel_layer.group_send)(
            f"parking_map_{complex_id}",
            {"type": "slot.update", "slot_id": slot.id, "code": slot.code, "status": slot.status},
        )
