from channels.generic.websocket import AsyncJsonWebsocketConsumer


class GuardFeedConsumer(AsyncJsonWebsocketConsumer):
    """ws/guard-feed/<complex_id>/ — instant ANPR plate reads for the guard tablet UI."""

    async def connect(self):
        self.complex_id = self.scope["url_route"]["kwargs"]["complex_id"]
        self.group_name = f"guard_feed_{self.complex_id}"
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def gate_event(self, event):
        await self.send_json(event)
