from django.contrib import admin

from .models import AccessLog, ANPRCamera, BarrierController, OccupancySensor

admin.site.register(ANPRCamera)
admin.site.register(BarrierController)
admin.site.register(OccupancySensor)


@admin.register(AccessLog)
class AccessLogAdmin(admin.ModelAdmin):
    list_display = ("license_plate", "camera", "decision", "reason", "created_at")
    list_filter = ("decision", "camera")
    search_fields = ("license_plate",)
