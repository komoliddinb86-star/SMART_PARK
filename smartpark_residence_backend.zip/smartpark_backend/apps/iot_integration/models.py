from django.db import models


class DeviceHealth(models.TextChoices):
    ONLINE = "ONLINE", "Onlayn"
    OFFLINE = "OFFLINE", "Oflayn"
    FAULT = "FAULT", "Nosozlik"


class ANPRCamera(models.Model):
    complex = models.ForeignKey("complexes.ResidentialComplex", on_delete=models.CASCADE, related_name="cameras")
    gate_name = models.CharField(max_length=100, help_text="Masalan: 'Asosiy kirish darvozasi'")
    device_uid = models.CharField(max_length=100, unique=True)
    health = models.CharField(max_length=10, choices=DeviceHealth.choices, default=DeviceHealth.ONLINE)
    last_seen_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.gate_name} ({self.complex})"


class BarrierController(models.Model):
    camera = models.OneToOneField(ANPRCamera, on_delete=models.CASCADE, related_name="barrier")
    mqtt_topic = models.CharField(max_length=255, help_text="Ochish buyrug'i yuboriladigan MQTT topic")
    health = models.CharField(max_length=10, choices=DeviceHealth.choices, default=DeviceHealth.ONLINE)

    def __str__(self):
        return f"Barrier @ {self.camera.gate_name}"


class OccupancySensor(models.Model):
    slot = models.OneToOneField("parking.ParkingSlot", on_delete=models.CASCADE, related_name="sensor")
    device_uid = models.CharField(max_length=100, unique=True)
    health = models.CharField(max_length=10, choices=DeviceHealth.choices, default=DeviceHealth.ONLINE)
    last_seen_at = models.DateTimeField(null=True, blank=True)


class AccessLog(models.Model):
    class Decision(models.TextChoices):
        GRANTED = "GRANTED", "Ruxsat berildi"
        DENIED = "DENIED", "Rad etildi"

    camera = models.ForeignKey(ANPRCamera, on_delete=models.CASCADE, related_name="access_logs")
    license_plate = models.CharField(max_length=20, db_index=True)
    decision = models.CharField(max_length=10, choices=Decision.choices)
    reason = models.CharField(max_length=255, blank=True)
    snapshot_url = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        indexes = [models.Index(fields=["license_plate", "-created_at"])]
