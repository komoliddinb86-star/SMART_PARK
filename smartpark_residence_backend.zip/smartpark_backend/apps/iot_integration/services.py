"""Service Layer — ANPR gate-access decision workflow."""
from __future__ import annotations

from django.utils import timezone

from apps.guest_access.models import GuestPass
from apps.parking.models import Vehicle

from .models import ANPRCamera, AccessLog


class GateAccessService:
    def __init__(self, camera: ANPRCamera):
        self.camera = camera

    def evaluate(self, license_plate: str, snapshot_url: str = "") -> AccessLog:
        vehicle = Vehicle.objects.filter(license_plate=license_plate, is_active=True).first()
        if vehicle is not None:
            return self._grant(license_plate, "Ro'yxatdan o'tgan rezident avtomobili", snapshot_url)

        guest_pass = GuestPass.objects.filter(
            vehicle_plate=license_plate, expires_at__gt=timezone.now(), revoked=False
        ).first()
        if guest_pass is not None:
            return self._grant(license_plate, "Faol mehmon ruxsatnomasi", snapshot_url)

        return self._deny(license_plate, "Ro'yxatda yo'q va faol ruxsatnoma topilmadi", snapshot_url)

    def _grant(self, plate: str, reason: str, snapshot_url: str) -> AccessLog:
        log = AccessLog.objects.create(
            camera=self.camera, license_plate=plate, decision=AccessLog.Decision.GRANTED,
            reason=reason, snapshot_url=snapshot_url,
        )
        self._open_barrier()
        self._broadcast_to_guard_dashboard(log)
        return log

    def _deny(self, plate: str, reason: str, snapshot_url: str) -> AccessLog:
        log = AccessLog.objects.create(
            camera=self.camera, license_plate=plate, decision=AccessLog.Decision.DENIED,
            reason=reason, snapshot_url=snapshot_url,
        )
        self._broadcast_to_guard_dashboard(log, alert=True)
        return log

    def _open_barrier(self):
        barrier = getattr(self.camera, "barrier", None)
        if barrier is None:
            return
        from core.utils.mqtt import publish_barrier_open

        publish_barrier_open(barrier.mqtt_topic)

    def _broadcast_to_guard_dashboard(self, log: AccessLog, alert: bool = False):
        from asgiref.sync import async_to_sync
        from channels.layers import get_channel_layer

        channel_layer = get_channel_layer()
        if channel_layer is None:
            return
        async_to_sync(channel_layer.group_send)(
            f"guard_feed_{self.camera.complex_id}",
            {
                "type": "gate.event",
                "plate": log.license_plate,
                "decision": log.decision,
                "reason": log.reason,
                "alert": alert,
                "snapshot_url": log.snapshot_url,
            },
        )
