from django.urls import path

from .views import ANPREventView

urlpatterns = [
    path("anpr-event/", ANPREventView.as_view(), name="iot-anpr-event"),
]
