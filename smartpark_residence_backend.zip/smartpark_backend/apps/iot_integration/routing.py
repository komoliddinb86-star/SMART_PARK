from django.urls import re_path

from .consumers import GuardFeedConsumer

websocket_urlpatterns = [
    re_path(r"ws/guard-feed/(?P<complex_id>\d+)/$", GuardFeedConsumer.as_asgi()),
]
