from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle
from rest_framework.views import APIView

from .models import ANPRCamera
from .serializers import ANPREventResultSerializer, ANPREventSerializer
from .services import GateAccessService


class DeviceAuthPermission(permissions.BasePermission):
    """IoT devices authenticate with a per-camera shared secret header, not JWT."""

    def has_permission(self, request):
        device_key = request.headers.get("X-Device-Key", "")
        return bool(device_key)  # TODO: validate against a per-camera secret store (HMAC)


class ANPREventView(APIView):
    """POST /api/v1/iot/anpr-event/ — called directly by camera firmware/gateway."""

    permission_classes = [DeviceAuthPermission]
    throttle_classes = [ScopedRateThrottle]
    throttle_scope = "iot"

    def post(self, request):
        serializer = ANPREventSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        camera = ANPRCamera.objects.filter(device_uid=serializer.validated_data["device_uid"]).first()
        if camera is None:
            return Response({"detail": "Noma'lum kamera"}, status=status.HTTP_404_NOT_FOUND)

        log = GateAccessService(camera).evaluate(
            license_plate=serializer.validated_data["license_plate"],
            snapshot_url=serializer.validated_data.get("snapshot_url", ""),
        )
        return Response(ANPREventResultSerializer(log).data, status=status.HTTP_200_OK)
