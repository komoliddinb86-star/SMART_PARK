from rest_framework import serializers

from .models import AccessLog


class ANPREventSerializer(serializers.Serializer):
    device_uid = serializers.CharField(max_length=100)
    license_plate = serializers.CharField(max_length=20)
    snapshot_url = serializers.URLField(required=False, allow_blank=True)


class ANPREventResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = AccessLog
        fields = ["id", "license_plate", "decision", "reason", "created_at"]
