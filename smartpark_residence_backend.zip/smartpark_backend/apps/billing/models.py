from django.conf import settings
from django.db import models


class Subscription(models.Model):
    apartment = models.ForeignKey("complexes.Apartment", on_delete=models.CASCADE, related_name="subscriptions")
    monthly_fee = models.DecimalField(max_digits=10, decimal_places=2)
    is_active = models.BooleanField(default=True)


class Fine(models.Model):
    class Reason(models.TextChoices):
        UNAUTHORIZED_PARKING = "UNAUTHORIZED_PARKING", "Ruxsatsiz to'xtash"
        GUEST_OVERSTAY = "GUEST_OVERSTAY", "Mehmon vaqtidan oshib qolishi"

    apartment = models.ForeignKey("complexes.Apartment", on_delete=models.CASCADE, related_name="fines")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.CharField(max_length=30, choices=Reason.choices)
    is_paid = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)


class PaymentTransaction(models.Model):
    class Provider(models.TextChoices):
        CLICK = "CLICK", "Click"
        PAYME = "PAYME", "Payme"

    class Status(models.TextChoices):
        PENDING = "PENDING", "Kutilmoqda"
        SUCCESS = "SUCCESS", "Muvaffaqiyatli"
        FAILED = "FAILED", "Xato"

    payer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="transactions")
    provider = models.CharField(max_length=10, choices=Provider.choices)
    provider_tx_id = models.CharField(max_length=100, unique=True, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    fine = models.ForeignKey(Fine, null=True, blank=True, on_delete=models.SET_NULL, related_name="transactions")
    subscription = models.ForeignKey(
        Subscription, null=True, blank=True, on_delete=models.SET_NULL, related_name="transactions"
    )
    created_at = models.DateTimeField(auto_now_add=True)
