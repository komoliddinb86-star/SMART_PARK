from rest_framework import serializers, viewsets
from rest_framework.routers import DefaultRouter

from .models import Fine, Subscription


class FineSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fine
        fields = ["id", "apartment", "amount", "reason", "is_paid", "created_at"]
        read_only_fields = fields


class SubscriptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subscription
        fields = ["id", "apartment", "monthly_fee", "is_active"]
        read_only_fields = fields


class FineViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = FineSerializer

    def get_queryset(self):
        return Fine.objects.filter(apartment__residents__user=self.request.user)


class SubscriptionViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = SubscriptionSerializer

    def get_queryset(self):
        return Subscription.objects.filter(apartment__residents__user=self.request.user)


router = DefaultRouter()
router.register("fines", FineViewSet, basename="fine")
router.register("subscriptions", SubscriptionViewSet, basename="subscription")

urlpatterns = router.urls
