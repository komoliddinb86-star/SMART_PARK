from django.contrib import admin

from .models import Fine, PaymentTransaction, Subscription

admin.site.register(Subscription)
admin.site.register(Fine)
admin.site.register(PaymentTransaction)
