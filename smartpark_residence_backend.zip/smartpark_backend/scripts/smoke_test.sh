#!/usr/bin/env bash
# SmartPark Residence — smoke test
#
# docker compose up --build ni ishga tushirgandan, migratsiya va
# seed_demo_data'dan KEYIN shu skriptni ishga tushiring:
#
#   chmod +x scripts/smoke_test.sh
#   ./scripts/smoke_test.sh
#
# Har bir qadam PASS/FAIL deb chiqadi. Birinchi FAIL'da to'xtaydi —
# aynan qaysi qatlam (auth / DB / API) singanini ko'rsatadi.

set -u
BASE_URL="${BASE_URL:-http://localhost}"
PASS=0
FAIL=0

check() {
  local name="$1"; local result="$2"
  if [ "$result" = "0" ]; then
    echo "  [PASS] $name"
    PASS=$((PASS+1))
  else
    echo "  [FAIL] $name"
    FAIL=$((FAIL+1))
  fi
}

echo "== 1. Server javob beryaptimi? =="
curl -s -o /dev/null -w "" "$BASE_URL/api/schema/"
check "GET /api/schema/ (Swagger sxemasi)" $?

echo "== 2. Demo rezident bilan login =="
LOGIN_RESPONSE=$(curl -s -X POST "$BASE_URL/api/v1/auth/login/" \
  -H "Content-Type: application/json" \
  -d '{"username": "resident", "password": "resident123"}')
ACCESS_TOKEN=$(echo "$LOGIN_RESPONSE" | grep -o '"access":"[^"]*"' | cut -d'"' -f4)
if [ -n "$ACCESS_TOKEN" ]; then check "POST /api/v1/auth/login/ (JWT olindi)" 0; else check "POST /api/v1/auth/login/ (JWT olindi)" 1; echo "  Javob: $LOGIN_RESPONSE"; fi

if [ -z "$ACCESS_TOKEN" ]; then
  echo ""
  echo "Login muvaffaqiyatsiz bo'lgani uchun keyingi testlar o'tkazib yuborildi."
  echo "Avval quyidagini tekshiring: migratsiya bajarilganmi, seed_demo_data ishga tushganmi?"
  echo ""
  echo "NATIJA: $PASS PASS, $FAIL FAIL"
  exit 1
fi

echo "== 3. Joylar ro'yxati (multi-tenant scoping) =="
SLOTS_RESPONSE=$(curl -s "$BASE_URL/api/v1/parking/slots/" -H "Authorization: Bearer $ACCESS_TOKEN")
echo "$SLOTS_RESPONSE" | grep -q '"code"'
check "GET /api/v1/parking/slots/ (kamida 1 ta joy qaytdi)" $?

echo "== 4. Bo'sh umumiy joy olish (Allocation Service) =="
ALLOCATE_RESPONSE=$(curl -s -X POST "$BASE_URL/api/v1/parking/slots/allocate/" \
  -H "Authorization: Bearer $ACCESS_TOKEN" -H "Content-Type: application/json" -d '{}')
echo "$ALLOCATE_RESPONSE" | grep -q '"status":"RESERVED"'
check "POST /api/v1/parking/slots/allocate/ (joy RESERVED qilindi)" $?

echo "== 5. Mehmon ruxsatnomalarim ro'yxati =="
GUEST_RESPONSE=$(curl -s "$BASE_URL/api/v1/guest-access/" -H "Authorization: Bearer $ACCESS_TOKEN")
echo "$GUEST_RESPONSE" | grep -q '"vehicle_plate"'
check "GET /api/v1/guest-access/ (seed'dagi mehmon ruxsatnomasi ko'rindi)" $?

echo ""
echo "NATIJA: $PASS PASS, $FAIL FAIL"
[ "$FAIL" = "0" ] && exit 0 || exit 1
