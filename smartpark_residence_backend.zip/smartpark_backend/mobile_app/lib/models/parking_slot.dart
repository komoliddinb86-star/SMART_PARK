/// Mirrors apps/parking/serializers.py::ParkingSlotSerializer
class ParkingSlot {
  final int id;
  final String code;
  final String slotType; // ASSIGNED | COMMON | GUEST | DISABLED | EMERGENCY
  final String status; // FREE | OCCUPIED | RESERVED | RELEASED_BY_OWNER | OUT_OF_SERVICE

  ParkingSlot({
    required this.id,
    required this.code,
    required this.slotType,
    required this.status,
  });

  factory ParkingSlot.fromJson(Map<String, dynamic> json) {
    return ParkingSlot(
      id: json['id'] as int,
      code: json['code'] as String,
      slotType: json['slot_type'] as String,
      status: json['status'] as String,
    );
  }
}
