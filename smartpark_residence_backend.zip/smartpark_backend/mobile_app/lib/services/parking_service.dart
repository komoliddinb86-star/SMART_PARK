import 'dart:async';
import 'dart:convert';

import 'package:web_socket_channel/web_socket_channel.dart';

import '../models/parking_slot.dart';
import 'api_client.dart';

class SlotUpdateEvent {
  final int slotId;
  final String code;
  final String status;
  SlotUpdateEvent({required this.slotId, required this.code, required this.status});
}

class ParkingService {
  /// GET /api/v1/parking/slots/ — see apps/parking/views.py::ParkingSlotViewSet
  static Future<List<ParkingSlot>> fetchSlots() async {
    final data = await ApiClient.get('/api/v1/parking/slots/');
    final results = (data is Map && data.containsKey('results')) ? data['results'] : data;
    return (results as List).map((e) => ParkingSlot.fromJson(e)).toList();
  }

  /// POST /api/v1/parking/slots/allocate/ — runs AllocationService server-side
  static Future<ParkingSlot> allocate() async {
    final data = await ApiClient.post('/api/v1/parking/slots/allocate/', {});
    return ParkingSlot.fromJson(data);
  }

  /// Connects to ws/parking/<complex_id>/ (apps/parking/consumers.py) for
  /// real-time FREE/OCCUPIED/RESERVED updates — no polling needed.
  static Stream<SlotUpdateEvent> liveUpdates(String complexId) {
    final wsBase = ApiClient.baseUrl.replaceFirst('http', 'ws');
    final channel = WebSocketChannel.connect(Uri.parse('$wsBase/ws/parking/$complexId/'));
    return channel.stream.map((raw) {
      final json = jsonDecode(raw as String) as Map<String, dynamic>;
      return SlotUpdateEvent(slotId: json['slot_id'], code: json['code'], status: json['status']);
    });
  }
}
