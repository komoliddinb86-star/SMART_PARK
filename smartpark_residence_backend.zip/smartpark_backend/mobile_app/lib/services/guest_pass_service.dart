import 'api_client.dart';

class GuestPassService {
  /// POST /api/v1/guest-access/ — see apps/guest_access/views.py::GuestPassViewSet
  /// Server signs the JWT and returns it in `signed_token`; encode that
  /// string into a QR code client-side (see guest_pass_screen.dart).
  static Future<Map<String, dynamic>> issue({
    required String vehiclePlate,
    required String guestName,
    required DateTime expiresAt,
  }) {
    return ApiClient.post('/api/v1/guest-access/', {
      'vehicle_plate': vehiclePlate,
      'guest_name': guestName,
      'expires_at': expiresAt.toUtc().toIso8601String(),
    }).then((v) => v as Map<String, dynamic>);
  }
}
