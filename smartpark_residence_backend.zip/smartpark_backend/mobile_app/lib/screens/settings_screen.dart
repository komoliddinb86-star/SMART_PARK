import 'package:flutter/material.dart';

import '../services/api_client.dart';
import '../theme/app_theme.dart';
import '../theme/senior_mode.dart';
import 'login_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sozlamalar'), backgroundColor: AppTheme.background),
      body: ValueListenableBuilder<bool>(
        valueListenable: SeniorMode.enabled,
        builder: (context, isEnabled, _) {
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              SwitchListTile(
                value: isEnabled,
                onChanged: (v) => SeniorMode.enabled.value = v,
                activeColor: AppTheme.gold,
                title: Text(
                  'Senior Mode',
                  style: TextStyle(color: AppTheme.textPrimary, fontSize: 16 * SeniorMode.textScale),
                ),
                subtitle: Text(
                  "Kattaroq shrift va tugmalar — keksalar va imkoniyati cheklanganlar uchun",
                  style: TextStyle(color: AppTheme.textMuted, fontSize: 12.5 * SeniorMode.textScale),
                ),
              ),
              const Divider(color: AppTheme.surface, height: 32),
              ListTile(
                title: Text('Chiqish', style: TextStyle(color: AppTheme.statusOccupied, fontSize: 16 * SeniorMode.textScale)),
                onTap: () async {
                  await ApiClient.clearTokens();
                  if (context.mounted) {
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginScreen()),
                      (route) => false,
                    );
                  }
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
