import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../services/api_client.dart';
import '../services/guest_pass_service.dart';
import '../theme/app_theme.dart';
import '../theme/senior_mode.dart';

class GuestPassScreen extends StatefulWidget {
  const GuestPassScreen({super.key});

  @override
  State<GuestPassScreen> createState() => _GuestPassScreenState();
}

class _GuestPassScreenState extends State<GuestPassScreen> {
  final _plateCtrl = TextEditingController();
  final _nameCtrl = TextEditingController();
  Duration _validFor = const Duration(hours: 4);
  String? _signedToken;
  bool _issuing = false;
  String? _error;

  @override
  void dispose() {
    _plateCtrl.dispose();
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _issue() async {
    if (_plateCtrl.text.trim().isEmpty) return;
    setState(() {
      _issuing = true;
      _error = null;
    });
    try {
      final result = await GuestPassService.issue(
        vehiclePlate: _plateCtrl.text.trim().toUpperCase(),
        guestName: _nameCtrl.text.trim(),
        expiresAt: DateTime.now().add(_validFor),
      );
      setState(() => _signedToken = result['signed_token'] as String?);
    } on ApiException {
      setState(() => _error = "Ruxsatnoma yaratilmadi. Qayta urinib ko'ring.");
    } finally {
      setState(() => _issuing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final textScale = SeniorMode.textScale;
    return Scaffold(
      appBar: AppBar(title: const Text('Mehmon ruxsatnomasi'), backgroundColor: AppTheme.background),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_signedToken == null) ...[
              TextField(
                controller: _plateCtrl,
                style: TextStyle(color: AppTheme.textPrimary, fontSize: 15 * textScale),
                decoration: const InputDecoration(hintText: "Mehmon avtomobili raqami (masalan: 01A777BB)"),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _nameCtrl,
                style: TextStyle(color: AppTheme.textPrimary, fontSize: 15 * textScale),
                decoration: const InputDecoration(hintText: "Mehmon ismi (ixtiyoriy)"),
              ),
              const SizedBox(height: 16),
              Text("Amal qilish muddati", style: TextStyle(color: AppTheme.textMuted, fontSize: 13 * textScale)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  _durationChip('2 soat', const Duration(hours: 2)),
                  _durationChip('4 soat', const Duration(hours: 4)),
                  _durationChip('1 kun', const Duration(days: 1)),
                ],
              ),
              const SizedBox(height: 24),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(_error!, style: const TextStyle(color: AppTheme.statusOccupied)),
                ),
              ElevatedButton(
                onPressed: _issuing ? null : _issue,
                child: _issuing
                    ? const SizedBox(
                        width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.background))
                    : Text('QR-kod yaratish', style: TextStyle(fontSize: 15 * textScale)),
              ),
            ] else ...[
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: QrImageView(data: _signedToken!, size: 220, backgroundColor: Colors.white),
              ),
              const SizedBox(height: 20),
              Text(
                '${_plateCtrl.text.trim().toUpperCase()} — darvoza kamerasiga ko\'rsating',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppTheme.textPrimary, fontSize: 15 * textScale),
              ),
              const SizedBox(height: 24),
              OutlinedButton(
                onPressed: () => setState(() => _signedToken = null),
                child: Text('Yangi ruxsatnoma', style: TextStyle(fontSize: 14 * textScale)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _durationChip(String label, Duration value) {
    final selected = _validFor == value;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => setState(() => _validFor = value),
      selectedColor: AppTheme.gold,
      backgroundColor: AppTheme.surface,
      labelStyle: TextStyle(color: selected ? AppTheme.background : AppTheme.textPrimary),
    );
  }
}
