import 'package:flutter/material.dart';

import '../services/api_client.dart';
import '../theme/app_theme.dart';
import 'home_shell.dart';

/// Calls POST /api/v1/auth/login/ (SimpleJWT — see apps/users/urls.py),
/// stores the access/refresh pair, then hands off to HomeShell.
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _login() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await ApiClient.post('/api/v1/auth/login/', {
        'username': _usernameCtrl.text.trim(),
        'password': _passwordCtrl.text,
      });
      await ApiClient.saveTokens(access: data['access'], refresh: data['refresh']);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const HomeShell()),
      );
    } on ApiException {
      setState(() => _error = "Login yoki parol noto'g'ri");
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('SmartPark',
                  style: TextStyle(color: AppTheme.gold, fontSize: 34, fontWeight: FontWeight.bold)),
              const Text('Residence', style: TextStyle(color: AppTheme.textPrimary, fontSize: 20)),
              const SizedBox(height: 40),
              TextField(
                controller: _usernameCtrl,
                style: const TextStyle(color: AppTheme.textPrimary),
                decoration: const InputDecoration(hintText: 'Login'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passwordCtrl,
                obscureText: true,
                style: const TextStyle(color: AppTheme.textPrimary),
                decoration: const InputDecoration(hintText: 'Parol'),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(color: AppTheme.statusOccupied)),
              ],
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _loading ? null : _login,
                  child: _loading
                      ? const SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.background))
                      : const Text('Kirish'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
