import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../theme/senior_mode.dart';
import 'guest_pass_screen.dart';
import 'parking_map_screen.dart';
import 'settings_screen.dart';

/// Root screen after login. Wraps the 3 primary resident-facing screens in
/// a bottom nav bar. `complexId` should come from GET /api/v1/auth/me/'s
/// `complex` field once real auth is wired up.
class HomeShell extends StatefulWidget {
  final String complexId;
  const HomeShell({super.key, this.complexId = '1'});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final screens = [
      ParkingMapScreen(complexId: widget.complexId),
      const GuestPassScreen(),
      const SettingsScreen(),
    ];

    return ValueListenableBuilder<bool>(
      valueListenable: SeniorMode.enabled,
      builder: (context, _, __) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(SeniorMode.textScale)),
          child: Scaffold(
            body: screens[_index],
            bottomNavigationBar: NavigationBar(
              selectedIndex: _index,
              onDestinationSelected: (i) => setState(() => _index = i),
              backgroundColor: AppTheme.surface,
              indicatorColor: AppTheme.gold.withOpacity(0.18),
              height: SeniorMode.minTouchTarget + 16,
              destinations: const [
                NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map, color: AppTheme.gold), label: 'Xarita'),
                NavigationDestination(icon: Icon(Icons.qr_code_outlined), selectedIcon: Icon(Icons.qr_code, color: AppTheme.gold), label: 'Mehmon'),
                NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings, color: AppTheme.gold), label: 'Sozlama'),
              ],
            ),
          ),
        );
      },
    );
  }
}
