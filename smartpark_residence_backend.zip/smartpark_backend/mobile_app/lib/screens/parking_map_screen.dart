import 'dart:async';

import 'package:flutter/material.dart';

import '../models/parking_slot.dart';
import '../services/parking_service.dart';
import '../theme/app_theme.dart';
import '../theme/senior_mode.dart';

/// Grid view of a zone's slots. Fetches the initial state over REST, then
/// patches individual cells in place as ws/parking/<complex_id>/ events
/// arrive — mirrors the TSJ admin dashboard shown in the web preview.
class ParkingMapScreen extends StatefulWidget {
  final String complexId;
  const ParkingMapScreen({super.key, required this.complexId});

  @override
  State<ParkingMapScreen> createState() => _ParkingMapScreenState();
}

class _ParkingMapScreenState extends State<ParkingMapScreen> {
  List<ParkingSlot> _slots = [];
  bool _loading = true;
  String? _error;
  StreamSubscription<SlotUpdateEvent>? _sub;

  @override
  void initState() {
    super.initState();
    _load();
    _sub = ParkingService.liveUpdates(widget.complexId).listen(_applyLiveUpdate, onError: (_) {
      // A dropped socket shouldn't crash the screen — the REST fetch already
      // rendered a correct snapshot; reconnect logic is a TODO for production.
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final slots = await ParkingService.fetchSlots();
      setState(() {
        _slots = slots;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = "Xarita yuklanmadi. Qayta urinib ko'ring.";
        _loading = false;
      });
    }
  }

  void _applyLiveUpdate(SlotUpdateEvent event) {
    setState(() {
      final idx = _slots.indexWhere((s) => s.id == event.slotId);
      if (idx != -1) {
        _slots[idx] = ParkingSlot(
          id: event.slotId,
          code: event.code,
          slotType: _slots[idx].slotType,
          status: event.status,
        );
      }
    });
  }

  Future<void> _allocate() async {
    try {
      await ParkingService.allocate();
      await _load();
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.statusCode == 409 ? "Hozircha bo'sh umumiy joy yo'q" : 'Xatolik yuz berdi')),
      );
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'FREE':
        return AppTheme.statusFree;
      case 'OCCUPIED':
        return AppTheme.statusOccupied;
      case 'RESERVED':
        return AppTheme.gold;
      default:
        return AppTheme.textMuted;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Jonli xarita'), backgroundColor: AppTheme.background),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _allocate,
        backgroundColor: AppTheme.gold,
        foregroundColor: AppTheme.background,
        label: Text('Joy olish', style: TextStyle(fontSize: 14 * SeniorMode.textScale)),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator(color: AppTheme.gold))
            : _error != null
                ? Center(child: Text(_error!, style: const TextStyle(color: AppTheme.textMuted)))
                : GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 0.9,
                    ),
                    itemCount: _slots.length,
                    itemBuilder: (context, i) {
                      final slot = _slots[i];
                      return Container(
                        decoration: BoxDecoration(
                          color: _statusColor(slot.status).withOpacity(0.16),
                          border: Border.all(color: _statusColor(slot.status).withOpacity(0.4)),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          slot.code,
                          style: TextStyle(
                            color: _statusColor(slot.status),
                            fontWeight: FontWeight.w600,
                            fontSize: 12 * SeniorMode.textScale,
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
