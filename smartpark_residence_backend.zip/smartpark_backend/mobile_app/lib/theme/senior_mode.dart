import 'package:flutter/foundation.dart';

/// Global, app-wide toggle. Kept as a plain ValueNotifier rather than pulling
/// in a state-management package — this is a scaffold, swap for
/// Provider/Riverpod/Bloc as the app grows.
class SeniorMode {
  static final ValueNotifier<bool> enabled = ValueNotifier<bool>(false);

  static const double normalTextScale = 1.0;
  static const double seniorTextScale = 1.35;

  static double get textScale => enabled.value ? seniorTextScale : normalTextScale;
  static double get minTouchTarget => enabled.value ? 56.0 : 44.0;
}
