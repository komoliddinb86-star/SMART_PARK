import 'package:flutter/material.dart';

/// SmartPark dark + brass theme — matches the parking-facility inspiration
/// board: near-black surfaces, a muted gold accent, plant-green success.
class AppTheme {
  static const background = Color(0xFF14120F);
  static const surface = Color(0xFF1F1B16);
  static const gold = Color(0xFFC9A227);
  static const textPrimary = Color(0xFFEDE7DD);
  static const textMuted = Color(0xFF8A8478);
  static const statusFree = Color(0xFF4C7A5E);
  static const statusOccupied = Color(0xFFB4483C);

  static ThemeData get dark {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      colorScheme: const ColorScheme.dark(
        primary: gold,
        surface: surface,
        onSurface: textPrimary,
      ),
      textTheme: const TextTheme(
        headlineMedium: TextStyle(color: textPrimary, fontWeight: FontWeight.w600),
        bodyMedium: TextStyle(color: textPrimary),
        bodySmall: TextStyle(color: textMuted),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: gold,
          foregroundColor: background,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}
