from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/auth/", include("apps.users.urls")),
    path("api/v1/complexes/", include("apps.complexes.urls")),
    path("api/v1/parking/", include("apps.parking.urls")),
    path("api/v1/iot/", include("apps.iot_integration.urls")),
    path("api/v1/guest-access/", include("apps.guest_access.urls")),
    path("api/v1/billing/", include("apps.billing.urls")),
    path("api/v1/disputes/", include("apps.disputes.urls")),
    path("api/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/docs/", SpectacularSwaggerView.as_view(url_name="schema"), name="swagger-ui"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
