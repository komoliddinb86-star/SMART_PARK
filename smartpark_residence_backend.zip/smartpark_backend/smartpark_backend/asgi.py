import os

from channels.auth import AuthMiddlewareStack
from channels.routing import ProtocolTypeRouter, URLRouter
from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "smartpark_backend.settings")

django_asgi_app = get_asgi_application()

from apps.parking.routing import websocket_urlpatterns as parking_ws  # noqa: E402
from apps.iot_integration.routing import websocket_urlpatterns as iot_ws  # noqa: E402

application = ProtocolTypeRouter(
    {
        "http": django_asgi_app,
        "websocket": AuthMiddlewareStack(URLRouter(parking_ws + iot_ws)),
    }
)
